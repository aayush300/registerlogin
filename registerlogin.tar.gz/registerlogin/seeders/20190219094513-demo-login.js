'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('Users', [
      {
        email:'aayush@gmail.com',
        password:'Secured'
      },
      {
        email:'aayush123@gmail.com',
        password:'Secured123'
      },
      
    ], {});
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('Users', null, {}); 
  }
};
