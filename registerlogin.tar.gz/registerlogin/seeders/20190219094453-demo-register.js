'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    
    
    return queryInterface.bulkInsert('Users', [
      {
        email:'aayush@gmail.com',
        firstname:'Aayush',
        lastname:'Sirohi',
        password:'Secured'
      },
      {
        email:'aayush123@gmail.com',
        firstname:'Aayush123',
        lastname:'Sirohi123',
        password:'Secured123'
      },
      
    ], {});
    
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('Users', null, {});
  }
};
