
const Sequelize = require('sequelize');
const registerModels = require('./models/register');
const loginModels = require('./models/loginclr');


const db = new Sequelize('postgres://postgres:postgres@127.0.0.1:5432/registerlogin');

const Register = registerModels(db, Sequelize);
const Login = loginModels(db, Sequelize);

db
  .authenticate()
  .then(() => {
    console.log('DB connection has been established successfully.');
  })
  .catch((err) => {
    console.error('Unable to connect to the database:', err);
  });



// // module.exports.mongoose.Promise = global.Promise;mongoose.connect("mongodb://localhost:27017/node-demo",(err,database)=>{
// //     if(err)return console.log(err)
// //     require('./models')(app,{});
// //     app.listen(port,() =>{
// //         console.log('we are on  port live ');
// //     })
// //     } ,
// //     { useNewUrlParser: true });



// const mongoose = require('mongoose');

// module.export = function(){
 
// let dev_db_url = 'mongodb://someuser:abcd1234@ds123619.mlab.com:23619/productstutorial';
// const mongoDB = process.env.MONGODB_URI || dev_db_url;
// mongoose.connect(mongoDB);
// mongoose.Promise = global.Promise;
// const db = mongoose.connection;
// db.on('error', console.error.bind(console, 'MongoDB connection error:'));
// };