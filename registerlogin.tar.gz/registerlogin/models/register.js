'use strict';
module.exports = (sequelize, DataTypes) => {
  const register = sequelize.define('register', {
    firstName: DataTypes.STRING,
    lastName: DataTypes.STRING,
    email: DataTypes.STRING,
    password: DataTypes.STRING
  }, {});
  register.associate = function(models) {
    // associations can be defined here
  };
  return register;
};