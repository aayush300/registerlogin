const logService = require('../services/loginService');



exports.product_create2= function (req, res) {
    
    logService.function1(req);


    
}