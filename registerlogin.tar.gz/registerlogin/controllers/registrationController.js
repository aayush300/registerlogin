const registerService = require('../services/registrationService');



exports.product_create1 = function (req, res) {
    
    product= registerService.function2(req);


    product.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('data entered successfully')
    })
};