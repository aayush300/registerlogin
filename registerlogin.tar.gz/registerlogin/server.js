const pg= require('pg');
const express     = require('express');
const bodyParser  =require('body-parser');
//const mongoose    =require('mongoose');


const app = express();
const router = express.Router();
const routes = require('./routes');

const port=8000;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}))

routes(router);

 app.listen(port, () => {
    console.log("Server listening on port " + port);
   });





