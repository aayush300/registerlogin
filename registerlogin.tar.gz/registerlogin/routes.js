const userController1 = require('./controllers/registrationController');
const userController2 = require('./controllers/loginController');

module.exports = (app) =>{

    app.post("/register", userController1.product_create1() );
    app.get("/login", userController2.product_create2() );
    
    };