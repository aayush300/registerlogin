const logService1 = require('../dbconnection.js');
exports.function2= (req)=> {
  
const query="Insert into register(firstname,lastname,emailid,password)values(req.body.firstname,req.body.lastname,req.body.emailid,req.body.password)";
return query;
}