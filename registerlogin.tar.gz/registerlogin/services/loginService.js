const logService1 = require('../dbconnection.js');
exports.function1= (req)=> {
  const db = new Sequelize('postgres://postgres:postgres@127.0.0.1:5432/registerlogin');
db.registers.findOne({  
    email: req.body.email,
    password:req.body.pass
  })
  .then(user => {
    console.log(`Found user: ${user}`);
    console.log('login sucessful');
  });
}